# gnl Slang-dictionary

A dictionary website that contains various slangs from parts of the world
